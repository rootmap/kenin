<script src="{{asset('site/js/jquery-3.4.1.min.220afd743d.js')}}" type="text/javascript" integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" crossorigin="anonymous"></script>
<script src="{{asset('site/js/main.js')}}" type="text/javascript"></script>
<link rel="stylesheet" type="text/css" href="{{asset('site/css/jquery.datetimepicker.min.css')}}"/>
<script src="{{asset('site/js/jquery.datetimepicker.js')}}"></script>
<script src="{{asset('site/js/site.js')}}"></script>
<!-- [if lte IE 9]><script src="https://cdnjs.cloudflare.com/ajax/libs/placeholders/3.0.2/placeholders.min.js"></script><![endif] -->