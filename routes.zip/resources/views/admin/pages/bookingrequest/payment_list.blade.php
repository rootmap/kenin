
@extends("admin.layout.master")
@section("title","Payment Log")
@section("content")
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1>Payment Log</h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item active">Payment Log Data</li>
                </ol>
              </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    @include("admin.include.msg")
                </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>
        
        <section class="content">
          <div class="row">
            <div class="col-12">
              <!-- /.card -->
              <div class="card">

                <div class="card-header">
                  <h3 class="card-title">Payment / Transaction Data</h3>
                </div>


                
                <!-- /.card-header -->
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Card Number</th>
                            <th class="text-center">Customer Name</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Created At</th>
                            <th class="text-center">Actions</th>

                        </tr>
                    </thead>
                    <tbody>
                        @if(count($data))
                            @foreach($data as $row)  
                                <tr>
                                    <td class="text-center">{{$row->id}}</td>
                                    <td class="text-center">{{"XXXX XXXX XXXX ".substr($row->card_number,-4)}}</td>
                                    <td class="text-center">{{$row->card_holder_name}}</td>
                                    <td class="text-center">{{$row->amount}}</td>
                                    <td>{{formatDate($row->created_at)}}</td>
                                    <td>
                                        <div class="btn-group">
                                            @if($row->refund_status==1)
                                                <button class="btn btn-danger">Refunded</button>
                                            @else 
                                                <a href="{{url('bookingrequest/void/'.$row->id)}}" type="button" class="btn btn-default">
                                                    Refund Transaction 
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                            @endif
                                            
                                        </div>
                                    </td>
                                
                                </tr>
                            @endforeach
                        @endif
                                        
                    </tbody>
                    <tfoot>
                    <tr>
                        <th class="text-center">ID</th>
                        <th class="text-center">Card Number</th>
                        <th class="text-center">Customer Name</th>
                        <th class="text-center">Amount</th>
                        <th class="text-center">Created At</th>
                        <th class="text-center">Actions</th>


                    </tr>
                    </tfoot>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </section>
@endsection
@section("css")
    @include("admin.include.lib.datatable.css")
@endsection

@section("js")
    @include("admin.include.lib.datatable.js")
@endsection
        