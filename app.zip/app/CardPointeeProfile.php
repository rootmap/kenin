<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CardPointeeProfile extends Model
{
    //
}
